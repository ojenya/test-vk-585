self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "a20b830e70e7407d07a9b4d09161b61b",
    "url": "/index.html"
  },
  {
    "revision": "db74c68f0a88b625986d",
    "url": "/static/css/2.09e62520.chunk.css"
  },
  {
    "revision": "4b2ddc88c612d85c7922",
    "url": "/static/css/main.b493ce26.chunk.css"
  },
  {
    "revision": "db74c68f0a88b625986d",
    "url": "/static/js/2.fdb52e28.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "/static/js/2.fdb52e28.chunk.js.LICENSE.txt"
  },
  {
    "revision": "4b2ddc88c612d85c7922",
    "url": "/static/js/main.cbb48704.chunk.js"
  },
  {
    "revision": "6b8ff629877c5ee5c605",
    "url": "/static/js/runtime-main.d7723fed.js"
  }
]);